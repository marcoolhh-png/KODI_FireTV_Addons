# kinoger
# edit 2026-03-29 (fix: schneller, weniger Requests)

import re, json, base64, binascii, hashlib
from resources.lib.utils import isBlockedHoster
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle
from resources.lib.control import getSetting, quote_plus

SITE_IDENTIFIER = 'kinoger'
SITE_DOMAIN = 'kinoger.com'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            t = set([cleantitle.get(i) for i in set(titles) if i])
            years = (year, year+1, year-1)
            url = ''

            for sSearchText in titles:
                try:
                    oRequest = cRequestHandler(self.base_link)
                    oRequest.addParameters('story', sSearchText)
                    oRequest.addParameters('do', 'search')
                    oRequest.addParameters('subaction', 'search')
                    oRequest.addParameters('x', '0')
                    oRequest.addParameters('y', '0')
                    oRequest.addParameters('titleonly', '3')
                    oRequest.addParameters('submit', 'submit')
                    oRequest.cacheTime = 60 * 60 * 6
                    sHtmlContent = oRequest.request()
                    if not sHtmlContent: continue

                    pattern = r'class="title".*?href="([^"]+)">([^<]+).*?src="([^"]+)(.*?)</a> </span>'
                    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                    if not isMatch: continue

                    for sUrl, sName, sThumbnail, sDummy in aResult:
                        isYear, aYear = cParser.parse(sName, r'(.*?)\s+\((\d+)\)')
                        sYear = ''
                        sCleanName = sName
                        if isYear and aYear:
                            sCleanName, sYear = aYear[0]

                        if season == 0:
                            if cleantitle.get(sCleanName) not in t: continue
                            if sYear and int(sYear) not in years: continue
                            url = sUrl
                            break
                        else:
                            isTvshow = 'staffel' in sName.lower() or ';">S0' in sDummy
                            if not isTvshow: continue
                            sNameBase = re.split(r'\s*[-–]\s*\d+\.\s*Staffel|\s*\(\d+\)', sName)[0].strip()
                            if cleantitle.get(sNameBase) not in t: continue
                            m = re.search(r'(\d+)\.\s*Staffel', sName)
                            if m and int(m.group(1)) != season: continue
                            url = sUrl
                            break

                    if url: break
                except Exception:
                    continue

            if not url: return self.sources

            sHtmlContent = cRequestHandler(url).request()
            if not sHtmlContent: return self.sources

            if season > 0:
                # Serien: L11/L22/L33/L44 aus JS
                all_lists = []
                for js_var in ['sst', 'ollhd', 'pw', 'go']:
                    isMatch, container = cParser.parseSingleResult(
                        sHtmlContent, r'%s\.show.*?</script>' % js_var)
                    if isMatch:
                        container = container.replace('[', '<').replace(']', '>')
                        isMatch2, urls = cParser.parse(container, r"<'([^>]+)")
                        if isMatch2: all_lists.append(urls)

                if not all_lists: return self.sources
                ep_idx = episode - 1
                ep_urls = []
                for lst in all_lists:
                    if ep_idx < len(lst):
                        isMatch, found = cParser.parse(lst[ep_idx], r'(http[^\']+)')
                        if isMatch: ep_urls.extend(found)
                urls_to_resolve = ep_urls
            else:
                isMatch, aResult = cParser.parse(sHtmlContent, r"show[^>]\d,[^>][^>]'([^']+)")
                if not isMatch:
                    isMatch, aResult = cParser.parse(
                        sHtmlContent, r"'(https?://(?:kinoger|voe|dood)[^']+)'")
                if not isMatch: return self.sources
                urls_to_resolve = aResult

            self._resolve_urls(urls_to_resolve)

        except Exception:
            pass
        return self.sources

    def _resolve_urls(self, urls):
        # FIX: Erst schnelle Hoster (pw, re, andere) - kinoger.be (m3u8) nur als Fallback
        fast_urls = []
        be_urls = []
        for sUrl in urls:
            if not sUrl or not sUrl.startswith('http'): continue
            if 'youtube' in sUrl: continue
            if 'kinoger.be' in sUrl:
                be_urls.append(sUrl)
            else:
                fast_urls.append(sUrl)

        # Zuerst schnelle Hoster verarbeiten
        for sUrl in fast_urls:
            try:
                if 'kinoger.pw' in sUrl or 'kinoger.re' in sUrl:
                    oReq = cRequestHandler(sUrl, caching=False)
                    oReq.request()
                    realUrl = oReq.getRealUrl()
                    if realUrl and realUrl.startswith('http'):
                        quality = '1080p' if 'kinoger.re' in sUrl else '720p'
                        self.sources.append({'source': 'KinoGer', 'quality': quality,
                                              'language': 'de', 'url': realUrl,
                                              'direct': False, 'prioHoster': 20})
                else:
                    isBlocked, hoster, resolved_url, prioHoster = isBlockedHoster(sUrl)
                    if isBlocked: continue
                    if resolved_url:
                        self.sources.append({'source': hoster, 'quality': '720p',
                                              'language': 'de', 'url': resolved_url,
                                              'direct': True, 'prioHoster': prioHoster})
            except Exception:
                continue

        # FIX: kinoger.be (m3u8) nur wenn noch keine Quellen gefunden
        if not self.sources and be_urls:
            for sUrl in be_urls[:1]:  # Max 1 be-Hoster
                try:
                    oReq = cRequestHandler(sUrl, caching=False)
                    oReq.addHeaderEntry('Referer', self.base_link + '/')
                    sHtml = oReq.request()
                    if not sHtml: continue
                    isMatch, packed = cParser.parseSingleResult(
                        sHtml, r'(eval\s*\(function.*?)</script>')
                    if isMatch:
                        try:
                            from scrapers.modules import jsunpacker
                            sHtml = jsunpacker.unpack(packed)
                        except Exception:
                            pass
                    isMatch, hUrl = cParser.parseSingleResult(
                        sHtml, r'sources.*?file.*?(http[^"]+)')
                    if not isMatch: continue
                    hUrl = hUrl.replace('\\', '')
                    oReq2 = cRequestHandler(hUrl, caching=False)
                    oReq2.addHeaderEntry('Referer', 'https://kinoger.be/')
                    oReq2.removeNewLines(False)
                    m3u8 = oReq2.request()
                    if not m3u8 or 'CF-DDOS' in m3u8: continue
                    isMatch, qResult = cParser.parse(
                        m3u8, r'RESOLUTION=.*?x(\d+).*?\n(index[^\n]+)')
                    if isMatch:
                        for sQuality, sIdx in qResult:
                            qUrl = hUrl.split('video')[0] + sIdx.strip()
                            qUrl += '|Origin=https%3A%2F%2Fkinoger.be&Referer=https%3A%2F%2Fkinoger.be%2F'
                            self.sources.append({'source': 'KinoGer.be',
                                                  'quality': sQuality + 'p',
                                                  'language': 'de', 'url': qUrl,
                                                  'direct': True, 'prioHoster': 10})
                except Exception:
                    continue

    def resolve(self, url):
        return url
