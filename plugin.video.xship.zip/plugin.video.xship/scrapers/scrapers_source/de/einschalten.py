# einschalten
# 2024-09-05
# edit 2026-03-29 (portiert von xStream einschalten.py)

from resources.lib.utils import isBlockedHoster
import json
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules.tools import cParser
from scrapers.modules import cleantitle
from resources.lib.control import getSetting, quote_plus

SITE_IDENTIFIER = 'einschalten'
SITE_DOMAIN = 'einschalten.in'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        # FIX: Such-URL aus xStream-Version (JSON API)
        self.search_link = self.base_link + '/search?query=%s'
        # FIX: Watch-URL aus xStream: /api/movies/{id}/watch
        self.watch_link = self.base_link + '/api/movies/%s/watch'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        # Einschalten unterstützt nur Filme
        if season > 0: return self.sources
        try:
            t = [cleantitle.get(i) for i in set(titles) if i]
            found_id = None

            for sSearchText in set(titles):
                try:
                    oRequest = cRequestHandler(self.search_link % quote_plus(sSearchText))
                    oRequest.cacheTime = 60 * 60
                    sHtmlContent = oRequest.request()
                    if not sHtmlContent: continue

                    # FIX: Pattern aus xStream - liefert JSON mit id, title, year
                    # xStream nutzt: '{"id":([^,"]+).*?title":"([^"]+).*?Date":"([^-]+)'
                    pattern = r'"id":([^,"]+)[^}]*?"title":"([^"]+)[^}]*?"releaseDate":"([^-"]+)'
                    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                    if not isMatch: continue

                    for sId, sName, sYear in aResult:
                        try:
                            if int(sYear) == year and cleantitle.get(sName) in t:
                                found_id = sId.strip()
                                break
                        except Exception:
                            continue
                    if found_id: break
                except Exception:
                    continue

            if not found_id: return self.sources

            # Stream via /api/movies/{id}/watch holen
            sHtmlContent = cRequestHandler(self.watch_link % found_id).request()
            if not sHtmlContent or 'streamUrl' not in sHtmlContent: return self.sources

            try:
                jResult = json.loads(sHtmlContent)
                releaseName = jResult.get('releaseName', '')
                quality = '1080p' if '1080p' in releaseName else '720p' if '720p' in releaseName else 'SD'
                streamUrl = jResult['streamUrl']
                isBlocked, hoster, url, prioHoster = isBlockedHoster(streamUrl)
                if not isBlocked and url:
                    self.sources.append({'source': hoster, 'quality': quality, 'language': 'de',
                                         'url': url, 'direct': True, 'prioHoster': prioHoster})
            except Exception:
                pass

        except Exception:
            pass
        return self.sources

    def resolve(self, url):
        return url
